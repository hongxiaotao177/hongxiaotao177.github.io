package com.hongxt.aimanager;

import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private File backup;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 闪退修复：Activity 接管后再取私有目录，不在构造阶段调用 Context。
        backup = new File(getFilesDir(), "aimanager_backup.json");
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        web.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    public final class BackupBridge {
        @JavascriptInterface public synchronized String save(String base64) {
            File tmp = new File(getFilesDir(), "aimanager_backup.tmp");
            try {
                byte[] data = base64.getBytes(StandardCharsets.UTF_8);
                FileOutputStream out = new FileOutputStream(tmp);
                out.write(data); out.getFD().sync(); out.close();
                if (!tmp.renameTo(backup)) throw new Exception("rename_failed");
                return "1";
            } catch (Throwable t) { tmp.delete(); return "0"; }
        }
        @JavascriptInterface public synchronized String load() {
            try {
                if (!backup.isFile()) return "";
                byte[] buf = new byte[(int) backup.length()];
                FileInputStream in = new FileInputStream(backup);
                int off = 0, n;
                while (off < buf.length && (n = in.read(buf, off, buf.length - off)) >= 0) off += n;
                in.close();
                return new String(buf, 0, off, StandardCharsets.UTF_8);
            } catch (Throwable t) { return ""; }
        }
    }
}
