/* 新AI管家第一版功能 + 发送失败链修复。云账只记动作，不记问话和回答正文。 */
(function(){
'use strict';
var C=window.APP_CONFIG, STORE='aimanager_state_v2', LOGQ='aimanager_log_queue_v1';
var CMD_DONE='aimanager_command_done', CMD_ACTIVE='aimanager_command_active';
var state={chats:[],currentId:'',presets:[]}, busy=false, logQueue=[], flushTimer=null, flushBusy=false;
function $(id){return document.getElementById(id);}
function uid(prefix){return prefix+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function b64e(s){var b=new TextEncoder().encode(s),a='';for(var i=0;i<b.length;i++)a+=String.fromCharCode(b[i]);return btoa(a);}
function b64d(s){var a=atob(s.replace(/\s/g,'')),b=new Uint8Array(a.length);for(var i=0;i<a.length;i++)b[i]=a.charCodeAt(i);return new TextDecoder().decode(b);}
function defaultPresets(){return [
 {name:'简要说明',text:'请用清楚、简洁的话回答，先说结论，再说最重要的理由。'},
 {name:'帮我挑毛病',text:'请帮我挑毛病：先指出这句话或这个判断里不严谨、遗漏和容易误解的地方，再给出更稳妥的说法。'}
];}
function showToast(msg){$('toastText').textContent=String(msg);$('toast').classList.add('show');}
function hideToast(){$('toast').classList.remove('show');}
function ghUrl(path){return 'https://api.github.com/repos/'+C.github.owner+'/'+C.github.repo+'/contents/'+path.split('/').map(encodeURIComponent).join('/');}
async function ghGet(path){
 var r=await fetch(ghUrl(path),{headers:{Authorization:'Bearer '+C.github.token,Accept:'application/vnd.github+json'},cache:'no-store'});
 if(r.status===404)return null;
 if(!r.ok)throw new Error('github_'+r.status);
 var j=await r.json();return {text:b64d(j.content||''),sha:j.sha};
}
async function ghPut(path,text,sha,message){
 var body={message:message||'AI管家动作账',content:b64e(text)};if(sha)body.sha=sha;
 var r=await fetch(ghUrl(path),{method:'PUT',headers:{Authorization:'Bearer '+C.github.token,Accept:'application/vnd.github+json','Content-Type':'application/json'},body:JSON.stringify(body)});
 if(!r.ok)throw new Error('github_'+r.status);return r.json();
}
function logStep(event,detail){
 var row={ts:Date.now(),event:event,shell:C.shell,detail:detail||{}};
 logQueue.push(row);try{localStorage.setItem(LOGQ,JSON.stringify(logQueue.slice(-300)));}catch(e){}
 if(flushTimer)clearTimeout(flushTimer);flushTimer=setTimeout(flushLogs,700);
}
async function appendLogRows(rows){
 var groups={};rows.forEach(function(r){var d=new Date(r.ts).toISOString().slice(0,10);(groups[d]=groups[d]||[]).push(r);});
 for(var day of Object.keys(groups)){
  var path=C.github.logPrefix+day+'.jsonl',old=null;
  old=await ghGet(path);
  var text=(old&&old.text?old.text:'')+groups[day].map(function(r){return JSON.stringify(r);}).join('\n')+'\n';
  await ghPut(path,text,old&&old.sha,'AI管家动作账 '+day);
 }
}
async function flushLogs(){
 if(flushBusy||!logQueue.length||!navigator.onLine)return;flushBusy=true;
 var batch=logQueue.slice();logQueue=logQueue.slice(batch.length);
 try{await appendLogRows(batch);localStorage.setItem(LOGQ,JSON.stringify(logQueue));}
 catch(e){logQueue=batch.concat(logQueue);try{localStorage.setItem(LOGQ,JSON.stringify(logQueue.slice(-300)));}catch(e2){}}
 finally{flushBusy=false;if(logQueue.length)flushTimer=setTimeout(flushLogs,5000);}
}
function nativeSave(json){
 if(!window.AndroidBackup||typeof AndroidBackup.save!=='function')throw new Error('backup_bridge_missing');
 var ok=AndroidBackup.save(b64e(json));if(ok!=='1')throw new Error('backup_write_failed');
}
async function persistState(){
 var json=JSON.stringify(state),errors=[];
 try{localStorage.setItem(STORE,json);}catch(e){errors.push('local');}
 try{nativeSave(json);}catch(e){errors.push('backup');}
 if(errors.length)throw new Error(errors.join('_'));
}
function normalize(s){
 if(!s||typeof s!=='object')throw new Error('bad_state');
 s.chats=Array.isArray(s.chats)?s.chats:[];s.presets=Array.isArray(s.presets)&&s.presets.length?s.presets:defaultPresets();
 s.currentId=s.currentId||(s.chats[0]&&s.chats[0].id)||'';
 s.chats.forEach(function(c){c.messages=Array.isArray(c.messages)?c.messages:[];c.messages.forEach(function(m){if(m.status==='sending'){m.status='failed';m.failureReason='interrupted';}});});
 return s;
}
function loadState(){
 var raw='';try{raw=localStorage.getItem(STORE)||'';}catch(e){}
 if(!raw&&window.AndroidBackup&&typeof AndroidBackup.load==='function'){try{var b=AndroidBackup.load();if(b)raw=b64d(b);}catch(e){}}
 if(raw){try{state=normalize(JSON.parse(raw));return;}catch(e){}}
 state={chats:[],currentId:'',presets:defaultPresets()};
}
function currentChat(){return state.chats.find(function(c){return c.id===state.currentId;});}
function ensureChat(){
 var c=currentChat();if(c)return c;
 c={id:uid('chat'),title:'新问话',created:Date.now(),messages:[]};state.chats.unshift(c);state.currentId=c.id;return c;
}
function renderMessages(){
 var c=currentChat(),el=$('messages');
 if(!c){el.innerHTML='<div class="empty">写下第一句话，开始问话。</div>';return;}
 var h='';
 c.messages.forEach(function(m){
  h+='<div class="bubble user">'+esc(m.question)+'<div class="meta">提示词：'+esc(m.presetName)+'</div></div>';
  if(m.status==='sending'){
   var last=m.lastAttempts&&m.lastAttempts[m.lastAttempts.length-1];h+='<div class="meta">正在等待'+(last&&last.provider?esc(C.providers[last.provider].label):'回答')+'……</div>';
  }else if(m.status==='failed'){
   h+='<div class="bubble failed">这次没有得到回答。问话还在，可以直接重发。<div class="row"><button class="retry" data-retry="'+m.id+'">重新发送</button></div></div>';
  }else if(m.answer){
   h+='<div class="bubble answer" data-answer="'+m.id+'">'+esc(m.answer.text)+'<div class="meta">回答者：'+esc(C.providers[m.answer.provider].label)+'｜用时：'+(m.answer.ms/1000).toFixed(1)+'秒</div></div>';
   if(m.saveFailed)h+='<div class="row"><button data-save="'+m.id+'">重试保存</button><span class="meta">回答已回来，不会再叫别家。</span></div>';
  }
 });
 el.innerHTML=h;
}
function renderChats(){
 $('chatList').innerHTML=state.chats.map(function(c){return '<button class="chat-item" data-chat="'+c.id+'">'+esc(c.title||'问话')+'<br><small>'+c.messages.length+'条问话</small></button>';}).join('')||'<div class="empty">还没有历史对话</div>';
}
function renderPresets(){
 $('preset').innerHTML=state.presets.map(function(p,i){return '<option value="'+i+'">'+esc(p.name)+'</option>';}).join('');
 $('presetList').innerHTML=state.presets.map(function(p){return '<div class="chat-item">'+esc(p.name)+'</div>';}).join('');
}
function renderAll(){renderMessages();renderChats();renderPresets();}
async function callProvider(provider,question,promptText,signal){
 var p=C.providers[provider];
 var r=await fetch(p.url,{method:'POST',signal:signal,headers:{Authorization:'Bearer '+p.key,'Content-Type':'application/json'},body:JSON.stringify({model:p.model,messages:[{role:'system',content:promptText},{role:'user',content:question}],temperature:0.3,max_tokens:1600,stream:false})});
 if(!r.ok)throw new Error('http_'+r.status);
 var j=await r.json(),text=j&&j.choices&&j.choices[0]&&j.choices[0].message&&j.choices[0].message.content;
 if(Array.isArray(text))text=text.map(function(x){return x.text||'';}).join('');
 if(typeof text!=='string'||!text.trim())throw new Error('empty_answer');return text;
}
async function executeMessage(chat,msg,isRetry,origin){
 if(msg.busy)return {status:'busy'};msg.busy=true;msg.status='sending';msg.saveFailed=false;msg.displayFailed=false;renderMessages();
 var result;
 try{
  result=await SendChain.execute({question:msg.question,promptText:msg.promptText,presetName:msg.presetName,order:msg.order.slice(),isRetry:isRetry,origin:origin||'manual',chatId:chat.id,messageId:msg.id,
   callProvider:callProvider,log:logStep,timeoutMs:window.__TEST_TIMEOUT__||25000,
   onAttempts:async function(a){msg.lastAttempts=a;msg.attempts=(msg.attempts||[]).concat(a.slice(-1));renderMessages();},
   persist:async function(answer){msg.answer=answer;msg.status='answered';await persistState();},
   display:async function(answer){msg.answer=answer;msg.status='answered';if(state.currentId===chat.id){renderMessages();if(!document.querySelector('[data-answer="'+msg.id+'"]'))throw new Error('display_missing');}}
  });
 }catch(e){result={status:'all_failed',attempts:[]};logStep('chain_exception',{chat:chat.id,message:msg.id,reason:String(e.message||e).slice(0,100)});}
 if(result.status==='all_failed'){msg.status='failed';}
 else{msg.status='answered';msg.saveFailed=result.status==='save_failed';msg.displayFailed=result.status==='display_failed';}
 msg.busy=false;
 try{await persistState();if(msg.answer&&result.status!=='display_failed')msg.saveFailed=false;}catch(e){if(msg.answer)msg.saveFailed=true;}
 renderAll();
 logStep('send_finish',{chat:chat.id,message:msg.id,status:result.status,provider:result.provider||'',origin:origin||'manual'});
 if(msg.saveFailed)showToast('回答已经回来，但保存没完全成功。请点“重试保存”，不会重新问AI。');
 else if(result.status==='all_failed')showToast('几家都没有给出有效回答。请点原问话下面的“重新发送”。');
 return result;
}
async function sendFromInput(){
 if(busy)return;var text=$('question').value.trim();if(!text){showToast('请先写问话。');return;}
 var p=state.presets[Number($('preset').value)||0];if(!p){showToast('请先选提示词。');return;}
 busy=true;var c=ensureChat();var msg={id:uid('msg'),question:text,promptText:p.text,presetName:p.name,order:SendChain.DEFAULT_ORDER.slice(),status:'sending',attempts:[]};
 logStep('send_click',{chat:c.id,message:msg.id,chars:text.length,preset:p.name});logStep('send_accept',{chat:c.id,message:msg.id});
 c.messages.push(msg);if(c.messages.length===1)c.title=text.slice(0,20);$('question').value='';renderAll();
 try{await persistState();logStep('chat_saved',{chat:c.id,chats:state.chats.length});}catch(e){logStep('save_failed',{chat:c.id,stage:'question'});}
 await executeMessage(c,msg,false,'manual');busy=false;
}
async function retryMessage(msgId){
 if(busy)return;var c=currentChat(),m=c&&c.messages.find(function(x){return x.id===msgId;});if(!m)return;
 busy=true;logStep('retry_click',{chat:c.id,message:m.id});await executeMessage(c,m,true,'retry');busy=false;
}
async function retrySave(msgId){
 var c=currentChat(),m=c&&c.messages.find(function(x){return x.id===msgId;});if(!m||!m.answer)return;
 logStep('save_retry_click',{chat:c.id,message:m.id});
 m.saveFailed=false;try{await persistState();logStep('answer_saved',{chat:c.id,message:m.id,provider:m.answer.provider,save_attempt:'manual'});showToast('回答已保存。');}
 catch(e){m.saveFailed=true;logStep('save_failed',{chat:c.id,message:m.id,stage:'manual'});showToast('这次保存仍未成功，回答还在本页，不会重新问AI。');}
 renderMessages();
}
async function remoteTest(cmd){
 if(busy){logStep('remote_busy',{id:cmd.id});return;}
 var active=localStorage.getItem(CMD_ACTIVE)||'',done=localStorage.getItem(CMD_DONE)||'';
 if(done===cmd.id||active===cmd.id)return;
 localStorage.setItem(CMD_ACTIVE,cmd.id);busy=true;
 logStep('remote_cmd',{id:cmd.id,case:'diabetes_reverse',preset:'帮我挑毛病',order:SendChain.DEFAULT_ORDER});
 var c={id:uid('chat'),title:'真机检验',created:Date.now(),messages:[]};state.chats.unshift(c);state.currentId=c.id;
 var p=state.presets.find(function(x){return x.name==='帮我挑毛病';})||defaultPresets()[1];
 var m={id:uid('msg'),question:'糖尿病能不能逆转',promptText:p.text,presetName:'帮我挑毛病',order:SendChain.DEFAULT_ORDER.slice(),status:'sending',attempts:[]};
 c.messages.push(m);renderAll();
 var result=await executeMessage(c,m,false,'remote');
 localStorage.setItem(CMD_DONE,cmd.id);localStorage.removeItem(CMD_ACTIVE);
 logStep('remote_done',{id:cmd.id,status:result.status,provider:result.provider||''});busy=false;
}
async function pollRemote(){
 if(document.hidden||busy||!navigator.onLine)return;
 try{var f=await ghGet(C.github.commandPath);if(!f)return;var cmd=JSON.parse(f.text);if(cmd&&cmd.id&&cmd.op==='repeat_failure_test')await remoteTest(cmd);}catch(e){}
}
function bind(){
 $('sendBtn').onclick=sendFromInput;$('newBtn').onclick=async function(){state.currentId='';renderAll();};
 $('historyBtn').onclick=function(){renderChats();$('drawer').classList.add('open');};$('closeDrawer').onclick=function(){$('drawer').classList.remove('open');};
 $('drawer').onclick=function(e){if(e.target===$('drawer'))$('drawer').classList.remove('open');};
 $('chatList').onclick=function(e){var b=e.target.closest('[data-chat]');if(b){state.currentId=b.getAttribute('data-chat');renderAll();$('drawer').classList.remove('open');}};
 $('messages').onclick=function(e){var r=e.target.closest('[data-retry]'),s=e.target.closest('[data-save]');if(r)retryMessage(r.getAttribute('data-retry'));if(s)retrySave(s.getAttribute('data-save'));};
 $('preset').onchange=function(){var p=state.presets[Number(this.value)||0];if(p)logStep('preset_selected',{name:p.name});};
 $('addPreset').onclick=async function(){var n=prompt('提示词名字');if(!n)return;var t=prompt('提示词内容');if(!t)return;state.presets.push({name:n.slice(0,30),text:t});renderPresets();$('preset').value=String(state.presets.length-1);try{await persistState();logStep('preset_saved',{name:n.slice(0,30)});}catch(e){showToast('提示词已加上，但保存未完全成功。');}};
 $('toastX').onclick=hideToast;document.addEventListener('visibilitychange',function(){if(!document.hidden)pollRemote();});
}
function init(){
 loadState();bind();renderAll();logStep('app_open',{});
 try{var pending=JSON.parse(localStorage.getItem(LOGQ)||'[]');if(Array.isArray(pending)&&pending.length){logQueue=pending.concat(logQueue);flushLogs();}}catch(e){}
 setTimeout(pollRemote,2500);setInterval(pollRemote,8000);
 window.__AI_MANAGER__={getState:function(){return state;},executeMessage:executeMessage,persistState:persistState,remoteTest:remoteTest,callProvider:callProvider};
 window.__APP_READY__=true;
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
