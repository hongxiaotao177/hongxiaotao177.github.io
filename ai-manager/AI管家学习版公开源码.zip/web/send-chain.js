/* 新AI管家发送失败链修复：只处理调用、接力、保存、显示，不碰其他功能。 */
(function (root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.SendChain = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var DEFAULT_ORDER = ['qwen', 'kimi', 'deepseek'];
  var TIMEOUT_MS = 25000;

  function validText(x) { return typeof x === 'string' && x.trim().length > 0; }
  function reasonOf(e) {
    if (!e) return 'unknown';
    return String(e.message || e).slice(0, 120);
  }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  async function callOne(provider, opts) {
    var controller = new AbortController();
    var timedOut = false;
    var timer = setTimeout(function () { timedOut = true; controller.abort(); }, opts.timeoutMs || TIMEOUT_MS);
    var started = Date.now();
    opts.log('ai_wait', { provider: provider, timeout_ms: opts.timeoutMs || TIMEOUT_MS });
    try {
      var answer = await opts.callProvider(provider, opts.question, opts.promptText, controller.signal);
      if (!validText(answer)) throw new Error('empty_answer');
      return { ok: true, answer: answer.trim(), ms: Date.now() - started };
    } catch (e) {
      return { ok: false, reason: timedOut ? 'timeout' : reasonOf(e), ms: Date.now() - started };
    } finally {
      clearTimeout(timer);
    }
  }

  async function execute(opts) {
    var order = (opts.order || DEFAULT_ORDER).slice();
    var attempts = [];
    opts.log(opts.isRetry ? 'retry_start' : 'send_start', {
      chat: opts.chatId, message: opts.messageId, preset: opts.presetName,
      order: order, chars: opts.question.length, origin: opts.origin || 'manual'
    });
    for (var i = 0; i < order.length; i++) {
      var provider = order[i];
      opts.log('ai_try', { chat: opts.chatId, message: opts.messageId, provider: provider });
      var r = await callOne(provider, opts);
      attempts.push({ provider: provider, ok: r.ok, reason: r.reason || '', ms: r.ms });
      if (opts.onAttempts) await opts.onAttempts(attempts.slice());
      if (r.ok) {
        opts.log('answer_received', { chat: opts.chatId, message: opts.messageId, provider: provider, ms: r.ms, answer_chars: r.answer.length });
        var answer = { text: r.answer, provider: provider, ms: r.ms, attempts: attempts.slice() };
        var saved = false;
        for (var s = 1; s <= 3; s++) {
          try {
            await opts.persist(answer);
            saved = true;
            opts.log('answer_saved', { chat: opts.chatId, message: opts.messageId, provider: provider, save_attempt: s });
            break;
          } catch (e) {
            opts.log('save_failed', { chat: opts.chatId, message: opts.messageId, provider: provider, save_attempt: s, reason: reasonOf(e) });
            if (s < 3) await sleep(300);
          }
        }
        /* 已拿到有效回答：无论保存或显示是否成功，都绝不再调用下一家。 */
        var displayed = false;
        for (var d = 1; d <= 2; d++) {
          try {
            await opts.display(answer);
            displayed = true;
            opts.log(d === 1 ? 'answer_displayed' : 'display_recovered', { chat: opts.chatId, message: opts.messageId, provider: provider });
            break;
          } catch (e2) {
            opts.log('display_failed', { chat: opts.chatId, message: opts.messageId, provider: provider, display_attempt: d, reason: reasonOf(e2) });
          }
        }
        return { status: saved && displayed ? 'ok' : (!saved ? 'save_failed' : 'display_failed'), provider: provider, answer: answer, attempts: attempts };
      }
      opts.log('ai_failed', { chat: opts.chatId, message: opts.messageId, provider: provider, reason: r.reason, ms: r.ms });
      if (i < order.length - 1) opts.log('provider_switch', { chat: opts.chatId, message: opts.messageId, from: provider, to: order[i + 1] });
    }
    opts.log('all_failed', { chat: opts.chatId, message: opts.messageId, attempts: attempts.length });
    return { status: 'all_failed', attempts: attempts };
  }

  return { execute: execute, DEFAULT_ORDER: DEFAULT_ORDER, TIMEOUT_MS: TIMEOUT_MS };
});
