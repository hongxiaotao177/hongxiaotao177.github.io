async page => {
 const fs=require('fs'),crypto=require('crypto');
 const results=[],errors=[];let scenario='same',versionReads=0,cloudText='';
 const ok=(name,value)=>{if(!value)throw new Error(name);results.push(name);};
 const source=fs.readFileSync('/mnt/agents/.tmp/ai-manager-work/base/web/index.html','utf8');
 const remoteHtml=fs.readFileSync('/mnt/agents/.tmp/ai-manager-work/web/index.html','utf8');
 const hash=s=>crypto.createHash('sha256').update(Buffer.from(s,'utf8')).digest('hex');
 const bytes=s=>Buffer.byteLength(s,'utf8');
 const b64=s=>Buffer.from(s,'utf8').toString('base64');
 const releases=[{version:'1.4.0',releasedAt:'2026-11-03',note:'检验新版'},{version:'1.3.0',releasedAt:'2026-11-02',note:'版本可见'},{version:'1.2.0',releasedAt:'2026-11-02',note:'学习版'}];
 function card(version,html,good){return JSON.stringify({version:version,releasedAt:'2026-11-02',note:'版本检查',web:{file:'index.html',bytes:bytes(html),sha256:good===false?'0'.repeat(64):hash(html)}});}
 function body(text){return {content:b64(text),sha:'x'};}
 page.on('pageerror',e=>errors.push(String(e)));
 await page.addInitScript(()=>{window.__TEST_TIMEOUT__=100;window.AndroidBackup={save(s){localStorage.setItem('__native_backup',s);return '1';},load(){return localStorage.getItem('__native_backup')||'';}};});
 await page.route('https://api.github.com/**',async route=>{
  const req=route.request(),url=req.url();
  if(req.method()==='PUT'){const p=req.postDataJSON();cloudText+=Buffer.from(p.content,'base64').toString('utf8');return route.fulfill({status:201,contentType:'application/json',body:'{}'});}
  if(url.includes('hongxiaotao177.github.io')&&url.includes('/ai-manager/')){
   if(scenario==='fallback')return route.fulfill({status:500,contentType:'application/json',body:'{}'});
   if(url.endsWith('/version.json')){versionReads++;let html=scenario==='new'||scenario==='bad'?remoteHtml:source;return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body(card(scenario==='new'||scenario==='bad'?'1.4.0':'1.3.0',html,scenario!=='bad')))});}
   if(url.endsWith('/releases.json'))return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body(JSON.stringify(releases)))});
   if(url.endsWith('/index.html'))return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body(remoteHtml))});
  }
  return route.fulfill({status:404,contentType:'application/json',body:'{}'});
 });
 await page.route('https://raw.githubusercontent.com/**',async route=>{
  const url=route.request().url();
  if(url.endsWith('/version.json'))return route.fulfill({status:200,contentType:'application/json',body:card('1.3.0',source,true)});
  if(url.endsWith('/releases.json'))return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(releases)});
  return route.fulfill({status:404,body:'{}'});
 });
 const file='file:///mnt/agents/.tmp/ai-manager-work/base/web/index.html';
 async function fresh(name){scenario=name;versionReads=0;cloudText='';await page.goto(file);await page.evaluate(()=>localStorage.clear());await page.reload();await page.waitForFunction(()=>window.__APP_READY__&&window.__UPDATE_TEST__);}
 await fresh('same');ok('指纹算法正确',await page.evaluate(async()=>await window.__UPDATE_TEST__.sha256('abc'))==='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
 await page.evaluate(()=>window.__UPDATE_TEST__.check(true));await page.waitForFunction(()=>window.__UPDATE_TEST__.state.state==='latest');
 ok('首页当前版本可见',(await page.locator('#currentVersion').textContent())==='1.3.0');
 ok('同版显示已最新',(await page.locator('#updateStatus').textContent()).includes('最新'));
 await page.click('#versionBtn');ok('逐版历史可点开',await page.locator('.release-item').count()>=3);ok('历史含当前版',(await page.locator('#modalBody').textContent()).includes('1.3.0'));await page.click('#modalClose');
 await fresh('new');await page.evaluate(()=>window.__UPDATE_TEST__.check(true));await page.waitForFunction(()=>window.__APP_VERSION__==='1.4.0'&&window.__UPDATE_TEST__&&window.__UPDATE_TEST__.state.version==='1.4.0',{timeout:15000});
 ok('新版写后回读并刷新',await page.evaluate(()=>{const u=JSON.parse(localStorage.getItem(window.__UPDATE_TEST__.cacheKey));return u&&u.validated&&u.version==='1.4.0';}));
 ok('刷新后首页版本改变',(await page.locator('#currentVersion').textContent())==='1.4.0');
 ok('成功回执保留',await page.evaluate(()=>{const m=JSON.parse(localStorage.getItem(window.__UPDATE_TEST__.metaKey));return m&&m.lastReceipt&&m.lastReceipt.version==='1.4.0';}));
 await page.waitForFunction(()=>window.__UPDATE_TEST__.state.state==='latest',{timeout:10000});ok('新版运行后不重复刷新',true);
 await fresh('bad');await page.evaluate(()=>window.__UPDATE_TEST__.check(true));await page.waitForFunction(()=>window.__UPDATE_TEST__.state.state==='failed');
 ok('坏指纹拒绝更新',await page.evaluate(()=>!localStorage.getItem(window.__UPDATE_TEST__.cacheKey)&&window.__APP_VERSION__==='1.3.0'));
 ok('失败常驻红字',(await page.locator('#updateStatus').textContent()).includes('更新没完成'));
 ok('失败黑框可点叉关闭',await page.locator('#toast').evaluate(e=>e.classList.contains('show')));await page.click('#toastX');ok('黑框点叉后关闭',!(await page.locator('#toast').evaluate(e=>e.classList.contains('show'))));
 await fresh('fallback');await page.evaluate(()=>window.__UPDATE_TEST__.check(true));await page.waitForFunction(()=>window.__UPDATE_TEST__.state.state==='latest');ok('公开接口失败走备用下载',true);
 await fresh('same');await page.evaluate(source=>{localStorage.setItem(window.__UPDATE_TEST__.cacheKey,JSON.stringify({version:'1.2.0',validated:true,html:source.replace("window.__APP_VERSION__='1.3.0'","window.__APP_VERSION__='1.2.0'")}));},source);await page.reload();await page.waitForFunction(()=>window.__UPDATE_TEST__);ok('旧缓存不盖新包',await page.evaluate(()=>window.__APP_VERSION__==='1.3.0'));
 await fresh('same');let pair=await page.evaluate(()=>Promise.all([window.__UPDATE_TEST__.check(true),window.__UPDATE_TEST__.check(true)]));ok('重复检查不并发',pair[0].state==='latest'&&pair[1].state==='busy');ok('并发只读一次版本牌',versionReads===1);
 ok('云账不含网页正文',!cloudText.includes('<html')&&!cloudText.includes('问话后可直接'));
 ok('页面错误为零',errors.length===0);
 return {passed:results,errors};
}
