const assert=require('assert');
const SC=require('../web/send-chain.js');
function base(over){return Object.assign({question:'糖尿病能不能逆转',promptText:'挑毛病',presetName:'帮我挑毛病',chatId:'c',messageId:'m',order:SC.DEFAULT_ORDER,timeoutMs:25,log:(e,d)=>{},onAttempts:async()=>{},persist:async()=>{},display:async()=>{}},over||{});}
(async()=>{
 let calls=[],events=[];
 let r=await SC.execute(base({callProvider:(p,q,t,signal)=>{calls.push(p);if(p==='qwen')return new Promise((_,rej)=>signal.addEventListener('abort',()=>rej(new Error('aborted'))));return Promise.resolve('有效回答');},log:(e)=>events.push(e)}));
 assert.equal(r.status,'ok');assert.deepEqual(calls,['qwen','kimi']);assert(events.includes('provider_switch'));assert(events.includes('answer_saved'));assert(events.includes('answer_displayed'));
 calls=[];events=[];
 r=await SC.execute(base({isRetry:true,callProvider:p=>{calls.push(p);return Promise.reject(new Error('http_500'));},log:e=>events.push(e)}));
 assert.equal(r.status,'all_failed');assert.deepEqual(calls,['qwen','kimi','deepseek']);assert(events.includes('retry_start'));
 calls=[];let saves=0;
 r=await SC.execute(base({callProvider:p=>{calls.push(p);return Promise.resolve('已经拿到的回答');},persist:async()=>{saves++;throw new Error('disk_full');}}));
 assert.equal(r.status,'save_failed');assert.deepEqual(calls,['qwen']);assert.equal(saves,3);
 calls=[];
 r=await SC.execute(base({callProvider:p=>{calls.push(p);return Promise.resolve('已经拿到的回答');},display:async()=>{throw new Error('display_error');}}));
 assert.equal(r.status,'display_failed');assert.deepEqual(calls,['qwen']);
 calls=[];
 r=await SC.execute(base({callProvider:p=>{calls.push(p);return Promise.resolve(p==='qwen'?'   ':'另一家有效回答');}}));
 assert.equal(r.status,'ok');assert.deepEqual(calls,['qwen','kimi']);assert.equal(r.provider,'kimi');
 console.log('发送链五项测试全部通过');
})().catch(e=>{console.error(e);process.exit(1);});
