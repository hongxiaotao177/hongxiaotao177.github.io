async page => {
 const results=[],errors=[];let scenario='',aiCalls=[],cloudText='',cmdId='';
 const ok=(name,value)=>{if(!value)throw new Error(name);results.push(name);};
 page.on('pageerror',e=>errors.push(String(e)));
 await page.addInitScript(()=>{
  window.__TEST_TIMEOUT__=120;window.__backupFail=false;
  window.AndroidBackup={save(s){if(window.__backupFail)return '0';localStorage.setItem('__native_backup',s);return '1';},load(){return localStorage.getItem('__native_backup')||'';}};
 });
 await page.route('https://api.github.com/**',async route=>{
  const req=route.request(),url=req.url();
  if(req.method()==='PUT'){const body=req.postDataJSON();cloudText+=Buffer.from(body.content,'base64').toString('utf8');return route.fulfill({status:201,contentType:'application/json',body:'{}'});}
  if(url.includes('ai_manager_commands')&&scenario==='remote'){
   const text=JSON.stringify({id:cmdId,op:'repeat_failure_test'});
   return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({content:Buffer.from(text).toString('base64'),sha:'x'})});
  }
  return route.fulfill({status:404,contentType:'application/json',body:'{}'});
 });
 const aiHandler=async route=>{
  const url=route.request().url(),p=url.includes('dashscope')?'qwen':url.includes('moonshot')?'kimi':'ds';
  const body=route.request().postDataJSON(),sys=body.messages[0].content,usr=body.messages[body.messages.length-1].content;
  const main=sys.includes('学习管家');aiCalls.push({p,sys,main});
  if(scenario==='timeout'&&main&&p==='qwen'){await new Promise(r=>setTimeout(r,700));return route.fulfill({status:500,body:'{}'});}
  if(main&&(scenario==='allfail'||(scenario==='retry'&&p!=='ds')))return route.fulfill({status:500,contentType:'application/json',body:'{}'});
  let text='';
  if(sys.includes('知识地图编辑')){
   if(scenario==='badmap')text='不是脑图';
   else{const notes=JSON.parse(usr.split('\n解释和文献：')[1]||'[]');text=JSON.stringify({nodes:[{id:'root',title:'糖尿病逆转',parentId:'',summary:'学习主题',annotationIds:notes.map(x=>x.annotationId),messageIds:[]},{id:'child',title:'生活方式',parentId:'root',summary:'饮食和运动',annotationIds:[],messageIds:[]}]});}
  }else if(sys.includes('复核员'))text='已复核：内容可读；文献真实性仍需查证。';
  else if(sys.includes('书籍整理编辑'))text='糖尿病逆转学习稿\n\n先说明结论，再逐段解释。\n\n参考文献\n[1] 示例机构. 示例文献. 2024.';
  else text='**糖尿病逆转**是缓解，不等于治愈。\n需要长期随访。\n\n参考文献\n[1] 示例机构. 示例高质量文献. 2024.';
  return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({choices:[{message:{content:text}}]})});
 };
 await page.route('https://dashscope.aliyuncs.com/**',aiHandler);await page.route('https://api.moonshot.cn/**',aiHandler);await page.route('https://api.deepseek.com/**',aiHandler);
 const file='file:///mnt/agents/.tmp/ai-manager-work/base/web/index.html';
 async function fresh(name){scenario=name;aiCalls=[];cloudText='';await page.goto(file);await page.evaluate(()=>{localStorage.clear();window.__lastBackup='';window.__backupFail=false;});await page.reload();await page.waitForFunction(()=>window.__APP_READY__);}
 async function send(text='糖尿病能不能逆转'){await page.fill('#question',text);await page.click('#sendBtn');}
 async function answered(){await page.waitForFunction(()=>{const s=window.__LEARNING_TEST__.getState();return s.chats[0]&&s.chats[0].messages[0]&&s.chats[0].messages[0].status==='answered';});}
 await fresh('timeout');await send();await answered();
 ok('超时自动换下一家',aiCalls.filter(x=>x.main).map(x=>x.p).join(',')==='qwen,kimi');
 ok('回答者与耗时保留',(await page.locator('.meta').allTextContents()).some(x=>x.includes('Kimi')&&x.includes('用时')));
 await fresh('allfail');await send();await page.waitForSelector('[data-retry]');ok('三家全败可原样重发',aiCalls.filter(x=>x.main).length===3);
 scenario='retry';aiCalls=[];await page.click('[data-retry]');await answered();ok('重发仍按原顺序',aiCalls.filter(x=>x.main).map(x=>x.p).join(',')==='qwen,kimi,ds');
 ok('重发不重复问话',await page.locator('.bubble.question').count()===1);
 await fresh('savefail');await page.evaluate(()=>{window.__backupFail=true;const orig=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='aimanager_learning_state_v1')throw new Error('full');return orig.call(this,k,v);};});await send();await page.waitForSelector('[data-save]');
 ok('保存失败不换一家重答',aiCalls.filter(x=>x.main).length===1);ok('保存失败仍显示回答',await page.locator('.answer-text').count()===1);
 await fresh('normal');await send();await page.waitForFunction(()=>{const s=window.__LEARNING_TEST__.getState(),c=s.chats[0];return c&&c.mapStatus==='done'&&c.messages[0].review&&c.messages[0].review.status==='done';});
 let state=await page.evaluate(()=>window.__LEARNING_TEST__.getState());
 ok('完整学习问话',state.chats[0].messages[0].answer.text.includes('糖尿病逆转'));
 ok('另一家核对',state.chats[0].messages[0].review.provider!==state.chats[0].messages[0].answer.provider);
 ok('脑图自动生长',state.chats[0].map.nodes.length===2);
 ok('正文分句点亮',await page.locator('.answer-text .glow').count()>=2);
 const glow=page.locator('.answer-text .glow').first();await glow.hover();await page.mouse.down();await page.waitForTimeout(650);await page.mouse.up();
 ok('长按弹出选择',await page.locator('[data-glow-action="explain"]').isVisible());await page.click('[data-glow-action="explain"]');
 await page.waitForFunction(()=>{const s=window.__LEARNING_TEST__.getState(),a=s.chats[0].annotations[0];return a&&a.status==='done'&&a.review&&a.review.status==='done';});await page.click('#modalClose');
 state=await page.evaluate(()=>window.__LEARNING_TEST__.getState());ok('点亮解释及复核',state.chats[0].annotations.length===1&&!!state.chats[0].annotations[0].review.text);
 await page.waitForFunction(()=>window.__LEARNING_TEST__.getState().chats[0].map.nodes[0].annotationIds.length===1);ok('脑图数字标关联解释',true);
 await page.click('[data-tab="repo"]');ok('仓库清除无用格式',!(await page.locator('#repoList').textContent()).includes('**'));
 await page.click('#bookBtn');await page.waitForFunction(()=>window.__LEARNING_TEST__.getState().books.length===1);ok('手动整理成书',(await page.locator('#bookList').textContent()).includes('糖尿病逆转学习稿'));
 ok('书名书稿可点亮',await page.locator('#bookList .glow').count()>=2);
 await page.reload();await page.waitForFunction(()=>window.__APP_READY__);state=await page.evaluate(()=>window.__LEARNING_TEST__.getState());ok('重开保留学习记忆',state.chats.length===1&&state.books.length===1&&state.chats[0].annotations.length===1);
 await page.evaluate(()=>{localStorage.removeItem('aimanager_learning_state_v1');localStorage.removeItem('aimanager_state_v2');});await page.reload();await page.waitForFunction(()=>window.__APP_READY__);state=await page.evaluate(()=>window.__LEARNING_TEST__.getState());ok('私有备份可恢复',state.chats.length===1&&state.books.length===1);
 scenario='badmap';await page.evaluate(()=>window.__LEARNING_TEST__.updateMap(window.__LEARNING_TEST__.getState().chats[0]));await page.waitForFunction(()=>window.__LEARNING_TEST__.getState().chats[0].mapStatus==='failed');
 state=await page.evaluate(()=>window.__LEARNING_TEST__.getState());ok('坏脑图保留旧图',state.chats[0].map.nodes.length===2);
 await fresh('normal');await page.evaluate(()=>{localStorage.setItem('aimanager_state_v2',JSON.stringify({currentId:'old1',presets:[{name:'旧提示词',text:'旧提示内容'}],chats:[{id:'old1',title:'旧问话',created:1,messages:[{id:'oldm',question:'旧问题',presetName:'旧提示词',status:'answered',answer:{text:'旧回答',provider:'qwen',ms:12}}]}]}));});await page.reload();await page.waitForFunction(()=>window.__APP_READY__);
 state=await page.evaluate(()=>window.__LEARNING_TEST__.getState());ok('旧问话旧提示词接回',state.chats[0].messages[0].question==='旧问题'&&state.presets[0].name==='旧提示词');
 await page.click('#newBtn');await send('新的一段学习');await answered();ok('新问话生成新历史',await page.evaluate(()=>window.__LEARNING_TEST__.getState().chats.length===2));
 await page.click('#historyBtn');await page.locator('[data-chat="old1"]').click();ok('历史可切换旧对话',await page.evaluate(()=>window.__LEARNING_TEST__.getState().currentId==='old1'));
 let prompts=['测试提示词','测试提示内容'];page.on('dialog',async d=>{await d.accept(prompts.shift()||'');});await page.click('#historyBtn');await page.click('#addPreset');await page.waitForFunction(()=>window.__LEARNING_TEST__.getState().presets.some(x=>x.name==='测试提示词'));ok('新增提示词保存',true);
 cmdId='learning-remote-simulation';await fresh('remote');await page.waitForFunction(()=>localStorage.getItem('aimanager_command_done')==='learning-remote-simulation',{timeout:12000});await page.waitForTimeout(1200);
 ok('远程指令自动执行',aiCalls.some(x=>x.main));ok('远程动作账完整',['remote_cmd','answer_received','answer_saved','answer_displayed','remote_done'].every(x=>cloudText.includes(x)));
 ok('云账不含问话和回答正文',!cloudText.includes('糖尿病')&&!cloudText.includes('这是用于检验的有效回答'));
 ok('页面错误为零',errors.length===0);
 return {passed:results,errors};
}
