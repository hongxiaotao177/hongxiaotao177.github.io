async page => {
 await page.unroute('https://api.github.com/**');
 scenario='realcloud';aiCalls=[];cloudText='';
 await page.goto('file:///mnt/agents/output/AI管家新壳/web/index.html');
 await page.evaluate(()=>localStorage.clear());await page.reload();await page.waitForFunction(()=>window.__APP_READY__);
 await page.fill('#question','糖尿病能不能逆转');await page.selectOption('#preset',{label:'帮我挑毛病'});await page.click('#sendBtn');
 await page.waitForSelector('[data-answer]');await page.waitForTimeout(2500);
 console.log('真实云端写入页面动作完成');
}