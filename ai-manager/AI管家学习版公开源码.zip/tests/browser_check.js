async page => {
 const assert=(ok,msg)=>{if(!ok)throw new Error(msg)};
 const file='file:///mnt/agents/output/AI管家新壳/web/index.html';
 let scenario='', aiCalls=[], cloudText='', cmdId='';
 await page.addInitScript(() => {
   window.__TEST_TIMEOUT__=100;
   window.AndroidBackup={save(s){if(window.__backupFail)return '0';window.__lastBackup=s;return '1';},load(){return window.__lastBackup||'';}};
 });
 await page.route('https://api.github.com/**',async route=>{
   const req=route.request(),url=req.url();
   if(req.method()==='PUT'){const body=req.postDataJSON();cloudText+=decodeURIComponent(escape(atob(body.content)));return route.fulfill({status:201,contentType:'application/json',body:'{}'});}
   if(url.includes('ai_manager_commands')&&scenario==='remote'){
     const text=JSON.stringify({id:cmdId,op:'repeat_failure_test'});
     return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({content:btoa(unescape(encodeURIComponent(text))),sha:'x'})});
   }
   return route.fulfill({status:404,contentType:'application/json',body:'{}'});
 });
 const aiHandler=async route=>{
   const url=route.request().url();const p=url.includes('dashscope')?'qwen':url.includes('moonshot')?'kimi':'deepseek';aiCalls.push(p);
   if(scenario==='timeout'&&p==='qwen'){await new Promise(r=>setTimeout(r,1000));return route.fulfill({status:500,body:'{}'});}
   if(scenario==='allfail')return route.fulfill({status:500,contentType:'application/json',body:'{}'});
   if(scenario==='retry'&&p!=='deepseek')return route.fulfill({status:500,contentType:'application/json',body:'{}'});
   return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({choices:[{message:{content:'这是用于检验的有效回答。'}}]})});
 };
 await page.route('https://dashscope.aliyuncs.com/**',aiHandler);
 await page.route('https://api.moonshot.cn/**',aiHandler);
 await page.route('https://api.deepseek.com/**',aiHandler);
 async function fresh(name){scenario=name;aiCalls=[];cloudText='';await page.goto(file);await page.evaluate(()=>localStorage.clear());await page.reload();await page.waitForFunction(()=>window.__APP_READY__);}
 async function send(){await page.fill('#question','糖尿病能不能逆转');await page.selectOption('#preset',{label:'帮我挑毛病'});await page.click('#sendBtn');}
 // 1 千问超时，自动换Kimi，不能叫第三家
 await fresh('timeout');await send();await page.waitForSelector('[data-answer]');assert(aiCalls.join(',')==='qwen,kimi','超时接力顺序不对：'+aiCalls);assert((await page.locator('.meta').allTextContents()).some(x=>x.includes('Kimi')),'未显示回答者');
 // 2 三家全败有重发；重发后仍只有一条问话
 await fresh('allfail');await send();await page.waitForSelector('[data-retry]');assert(aiCalls.length===3,'三家全败调用数不对');scenario='retry';aiCalls=[];await page.click('[data-retry]');await page.waitForSelector('[data-answer]');assert(aiCalls.length===3,'重发未按原顺序走三家');assert(await page.locator('.bubble.user').count()===1,'重发新增了重复问话');
 // 3 已得回答但双写失败，不能换下一家，页面给重试保存
 await fresh('savefail');await page.evaluate(()=>{window.__backupFail=true;window.__localFail=true;const orig=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='aimanager_state_v2'&&window.__localFail)throw new Error('full');return orig.call(this,k,v);};});await send();await page.waitForSelector('[data-save]');assert(aiCalls.join(',')==='qwen','保存失败错叫下一家：'+aiCalls);assert(await page.locator('[data-answer]').count()===1,'保存失败后回答未显示');
 // 4 远程指令自动执行同一案例，并回完整动作账
 cmdId='real-device-simulation';await fresh('remote');await page.waitForSelector('[data-answer]',{timeout:10000});assert(aiCalls.length>=1,'远程检验未调用AI');await page.waitForTimeout(1200);assert(cloudText.includes('remote_cmd'),'云账缺远程接住');assert(cloudText.includes('answer_received'),'云账缺回答');assert(cloudText.includes('answer_saved'),'云账缺保存');assert(cloudText.includes('answer_displayed'),'云账缺显示');assert(cloudText.includes('remote_done'),'云账缺完成');assert(!cloudText.includes('糖尿病'),'云账泄漏了问话正文');assert(!cloudText.includes('这是用于检验的有效回答'),'云账泄漏了回答正文');
 await page.screenshot({path:'/mnt/agents/output/AI管家修复版.png',fullPage:true});
 console.log('页面四项检验全部通过；脚本错误监控见浏览器控制台。');
}