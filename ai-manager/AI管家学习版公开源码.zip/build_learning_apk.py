#!/usr/bin/env python3
"""用AAPT完整重建新AI管家学习版，不再手工补丁二进制清单。"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import zipfile

W = Path('/mnt/agents/.tmp/ai-manager-work')
BASE = W / 'AI管家修复版.apk'
OUT = Path('/mnt/agents/output/AI管家学习版.apk')
TOOLS = Path(os.environ.get('ANDROID_BUILD_TOOLS', '/mnt/agents/.tmp/android-tools/android-14'))
PLATFORM = Path(os.environ.get('ANDROID_PLATFORM', '/tmp/android-platform-35/android-35/android.jar'))


def run(cmd, **kwargs):
    env = dict(os.environ)
    env['LD_LIBRARY_PATH'] = str(TOOLS / 'lib64') + ':' + env.get('LD_LIBRARY_PATH', '')
    return subprocess.run(cmd, check=True, capture_output=True, env=env, **kwargs)


def main():
    for path in [BASE, TOOLS / 'aapt', TOOLS / 'zipalign', TOOLS / 'lib/apksigner.jar', PLATFORM]:
        if not path.is_file():
            raise FileNotFoundError(path)
    signing = json.loads((W / 'signing.json').read_text())
    with tempfile.TemporaryDirectory(prefix='ai-manager-build-') as tmp:
        t = Path(tmp)
        aapt = t / 'aapt'
        align = t / 'zipalign'
        shutil.copy2(TOOLS / 'aapt', aapt)
        shutil.copy2(TOOLS / 'zipalign', align)
        aapt.chmod(0o700)
        align.chmod(0o700)
        packed = t / 'packed.apk'
        unsigned = t / 'unsigned.apk'
        aligned = t / 'aligned.apk'
        run([
            str(aapt), 'package', '-f',
            '-M', str(W / 'base/android/app/src/main/AndroidManifest.xml'),
            '-I', str(PLATFORM),
            '--min-sdk-version', '24', '--target-sdk-version', '35',
            '-F', str(packed),
        ])
        shutil.copy2(packed, unsigned)
        with zipfile.ZipFile(BASE) as old, zipfile.ZipFile(unsigned, 'a', zipfile.ZIP_DEFLATED) as z:
            z.writestr('classes.dex', old.read('classes.dex'))
            for name in ['index.html', 'config.js', 'standalone-bridge.js', 'updater.js']:
                z.write(W / 'base/android/app/src/main/assets' / name, 'assets/' + name)
        run([str(align), '-f', '4', str(unsigned), str(aligned)])
        run([
            'java', '-jar', str(TOOLS / 'lib/apksigner.jar'), 'sign',
            '--ks', str(W / 'debug.keystore'),
            '--ks-pass', 'pass:' + signing['storePassword'],
            '--key-pass', 'pass:' + signing['keyPassword'],
            '--ks-key-alias', signing['keyAlias'],
            '--v1-signing-enabled=false', '--v2-signing-enabled=true',
            '--v3-signing-enabled=false', '--out', str(OUT), str(aligned),
        ])
        checked = run([
            'java', '-jar', str(TOOLS / 'lib/apksigner.jar'), 'verify',
            '--verbose', '--print-certs', str(OUT),
        ], text=True).stdout
        if 'Verified using v2 scheme (APK Signature Scheme v2): true' not in checked:
            raise RuntimeError('安卓v2签名核验失败')
        if '741fd63945938c73bd840ef5cefbf06e157be260bac78e4f216e087407919bad' not in checked:
            raise RuntimeError('签名证书与修复版不一致')
        with zipfile.ZipFile(OUT) as z, zipfile.ZipFile(BASE) as old:
            assert z.testzip() is None
            assert z.read('classes.dex') == old.read('classes.dex')
            for name in ['index.html', 'config.js', 'standalone-bridge.js', 'updater.js']:
                assert z.read('assets/' + name) == (W / 'base/android/app/src/main/assets' / name).read_bytes()
    data = OUT.read_bytes()
    print(json.dumps({
        'apk': str(OUT), 'bytes': len(data),
        'md5': hashlib.md5(data).hexdigest(),
        'sha256': hashlib.sha256(data).hexdigest(),
        'versionName': '1.3.0', 'versionCode': 6,
        'package': 'com.hongxt.aimanager.fix', 'signatureScheme': 'v2',
    }, ensure_ascii=False))


if __name__ == '__main__':
    main()
